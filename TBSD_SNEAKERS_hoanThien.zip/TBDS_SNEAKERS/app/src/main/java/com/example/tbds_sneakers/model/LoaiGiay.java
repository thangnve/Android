package com.example.tbds_sneakers.model;

public class LoaiGiay {
    public int maLoai;
    public String tenLoai;

    public LoaiGiay() {
    }

    public LoaiGiay(int maLoai, String tenLoai) {
        this.maLoai = maLoai;
        this.tenLoai = tenLoai;
    }
}