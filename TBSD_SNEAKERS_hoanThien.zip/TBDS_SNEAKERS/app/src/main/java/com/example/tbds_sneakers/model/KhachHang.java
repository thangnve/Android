package com.example.tbds_sneakers.model;

public class KhachHang {
    public int maKH;
    public String tenKH;
    public String diaChi;
    public String sdtKH;

    public KhachHang() {
    }

    public KhachHang(int maKH, String tenKH, String diaChi, String sdtKH) {
        this.maKH = maKH;
        this.tenKH = tenKH;
        this.diaChi = diaChi;
        this.sdtKH = sdtKH;
    }


}
