package com.example.tbds_sneakers.model;

public class Top {
    public String tenGiay;
    public int slTOP;

    public Top() {
    }
    public Top(String tenGiay, int slTOP) {
        this.tenGiay = tenGiay;
        this.slTOP = slTOP;
    }

}
